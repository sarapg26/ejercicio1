The OpenShift `nodejs` cartridge documentation can be found at:

https://github.com/openshift/origin-server/tree/master/cartridges/openshift-origin-cartridge-nodejs/README.md



wscat --connect ws://nodesocket-cdaley.rhcloud.com:8000

